

# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export POSTGRES_USERNAME=admin
export POSTGRES_PASSWORD=admin1234
export POSTGRES_HOST=udagramd-db
export POSTGRES_DB=udagramdb
export AWS_BUCKET=udagram-esiea-8765
export AWS_REGION=us-east-1
export AWS_PROFILE=default
export JWT_SECRET=testing
export URL=http://localhost:8100